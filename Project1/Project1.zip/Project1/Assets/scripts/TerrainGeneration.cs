﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TerrainGeneration : MonoBehaviour {

    //


	// Use this for initialization
	void Start () {
        // 

        // call generate

    }

    // Update is called once per frame
    void Update () {
	}

    void GenerateTerrain()
    {
        // initialize coordinates to 0
        // go through each row and column of terrain data
        // in each for loop, use appropriate coord and add it to 1/resolution(or coord?)
    }
}
